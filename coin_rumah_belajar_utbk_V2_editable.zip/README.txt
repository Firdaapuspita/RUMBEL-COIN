# COIN Rumah Belajar UTBK — V2
1. Buka `index.html` di browser.
2. Scroll ke bagian **Admin — Edit Isi Web**.
3. Kamu bisa mengubah judul/deskripsi dan menambah, mengedit, atau menghapus soal.
4. Data edit tersimpan di browser menggunakan localStorage.
5. Untuk website online yang datanya tersimpan di server dan bisa dikelola dari perangkat berbeda, tahap berikutnya adalah menghubungkan database/auth gratis.
